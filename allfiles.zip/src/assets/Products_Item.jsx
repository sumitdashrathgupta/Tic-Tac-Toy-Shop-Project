import React from "react"
import Car1 from "./Card image/car2.jpg"
import Car2 from "./Card image/car1.webp"
import Car3 from "./Card image/car3.jpg"
import Car4 from "./Card image/car4.jpg"
import Car5 from "./Card image/car5.jpg"
import Car6 from "./Card image/car6.jpg"
import Car7 from "./Card image/car7.jpg"
import Car8 from "./Card image/car10.webp"
import { CiStar } from "react-icons/ci";
import { MdOutlineStarPurple500 } from "react-icons/md";


const Products_Item = [
    {
        id: 1,
        Image: Car1,
        Title2: 'Blue Robot Lambo...',
        Title: "Blue Transformer Lamborghini remote control car with steel body and amazing look",
        Reting: () => (<><MdOutlineStarPurple500 /><MdOutlineStarPurple500 /><MdOutlineStarPurple500 /><MdOutlineStarPurple500 /><CiStar /></>),
        Price: "999",
        PreviousPrice: '1499',
        PercentOff: '33% off',
        Description: "Experience the thrill with this Blue Robot Lamborghini that transforms into a robot at the push of a button. Built with a sturdy steel body, it offers durability and a sleek design. Equipped with a responsive remote control for smooth navigation. Perfect for kids and collectors alike, combining fun and style."
    },
    {
        id: 2,
        Image: Car2,
        Title2: 'Yellow Color Mc Laren...',
        Title: "Yellow McLaren sports remote control car with sleek design and high speed",
        Reting: () => (<><MdOutlineStarPurple500 /><MdOutlineStarPurple500 /><MdOutlineStarPurple500 /><CiStar /><CiStar /></>),
        Price: "899",
        PreviousPrice: '1299',
        PercentOff: '31% off',
        Description: "Feel the speed with this Yellow McLaren sports car featuring a sleek aerodynamic design. The high-speed motor ensures fast performance, while the detailed interior adds a realistic touch. Ideal for racing enthusiasts looking for performance and style in one package."
    },
    {
        id: 3,
        Image: Car3,
        Title2: 'Mc Laren with osm design...',
        Title: "McLaren remote control car with eye-catching design and powerful performance",
        Reting: () => (<><MdOutlineStarPurple500 /><MdOutlineStarPurple500 /><MdOutlineStarPurple500 /><MdOutlineStarPurple500 /><MdOutlineStarPurple500 /></>),
        Price: "799",
        PreviousPrice: '1149',
        PercentOff: '30% off',
        Description: "Turn heads with this McLaren remote control car featuring an awesome two-tone design. The powerful battery ensures longer playtime, and the smooth controls make it easy to handle. Perfect for kids and adults who love stylish, high-performance RC cars."
    },
    {
        id: 4,
        Image: Car4,
        Title2: 'Remote Control Monster Truck...',
        Title: "Remote control monster truck with rugged tires and powerful suspension",
        Reting: () => (<><MdOutlineStarPurple500 /><MdOutlineStarPurple500 /><MdOutlineStarPurple500 /><CiStar /><CiStar /></>),
        Price: "899",
        PreviousPrice: '1399',
        PercentOff: '36% off',
        Description: "Conquer all terrains with this powerful remote control monster truck. Featuring rugged tires, a strong suspension system, and a bold design, it’s built for off-road adventures. The responsive controls provide a thrilling driving experience for kids and adults alike."
    },
    {
        id: 5,
        Image: Car5,
        Title2: 'Red Remote Control Car...',
        Title: "High-speed red remote control car with shock absorbers and bold look",
        Reting: () => (<><MdOutlineStarPurple500 /><MdOutlineStarPurple500 /><MdOutlineStarPurple500 /><MdOutlineStarPurple500 /><CiStar /></>),
        Price: "1099",
        PreviousPrice: '1699',
        PercentOff: '35% off',
        Description: "Experience adrenaline-pumping action with this high-speed red remote control car. Comes equipped with durable shock absorbers, a sleek aerodynamic body, and fast acceleration. Designed for both indoor racing and outdoor fun, offering hours of entertainment."
    },
    {
        id: 6,
        Image: Car6,
        Title2: 'Transformer Car with Remote...',
        Title: "Transforming sports car that converts into a robot with LED lights",
        Reting: () => (<><MdOutlineStarPurple500 /><MdOutlineStarPurple500 /><MdOutlineStarPurple500 /><CiStar /><CiStar /></>),
        Price: "1049",
        PreviousPrice: '1549',
        PercentOff: '32% off',
        Description: "This stunning transforming car shifts into a robot in seconds, accompanied by vibrant LED lights and sound effects. Comes with a multi-functional remote and rechargeable battery. Perfect for kids who love futuristic toys with exciting features."
    },
    {
        id: 7,
        Image: Car7,
        Title2: 'Blue Jeep 4x4 RC...',
        Title: "Blue 4x4 off-road RC jeep with realistic suspension and rugged build",
        Reting: () => (<><MdOutlineStarPurple500 /><MdOutlineStarPurple500 /><MdOutlineStarPurple500 /><MdOutlineStarPurple500 /><MdOutlineStarPurple500 /></>),
        Price: "949",
        PreviousPrice: '1399',
        PercentOff: '32% off',
        Description: "Explore tough terrains with this powerful 4x4 RC jeep. Designed for off-road action with durable tires, realistic suspension, and a robust build. The high-performance motor ensures powerful climbs and smooth rides on rough surfaces."
    },
    {
        id: 8,
        Image: Car8,
        Title2: 'Green Stunt Car with Lights...',
        Title: "Green remote control stunt car with 360° spins and colorful LED lights",
        Reting: () => (<><MdOutlineStarPurple500 /><MdOutlineStarPurple500 /><MdOutlineStarPurple500 /><CiStar /><CiStar /></>),
        Price: "799",
        PreviousPrice: '1249',
        PercentOff: '36% off',
        Description: "Perform amazing stunts with this green RC car that spins 360° and flips with ease. Equipped with vibrant LED lights, making it a visual treat during play. Durable design and responsive controls make it ideal for energetic kids and stunt lovers."
    }
];


export default Products_Item;
